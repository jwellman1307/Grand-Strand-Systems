package Task;

public class Task {
	
	private String taskId;
	private String name;
	private String description;
	
	public Task() {
		taskId = "INITIAL";
		name = "INITIAL";
		description = "INITIAL DESCRIPTION";
	}
	
	public Task(String taskId) {
		checkTaskId(taskId);
		name = "INITIAL";
		description = "INITIAL DESCRIPTION";
	}
	
	public Task(String taskId, String name) {
		checkTaskId(taskId);
		setName(name);
		description = "INITIAL DESCRIPTION";
	}
	
	public Task(String taskId, String name, String desc) {
		checkTaskId(taskId);
		setName(name);
		setDescription(desc);
	}
	
	public final String getTaskId() {
		return taskId;
	}
	
	public final String getName() {
		return name;
	}
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name is invalid. Name must not be empty or longer than 20 characters.");
		}
		else {
			this.name = name;
		}
	}
	
	public final String getDescription() {
		return description;
	}
	
	public void setDescription(String taskDescription) {
		if (taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Description is invalid. Decription must not be empty or longer than 50 characters.");
		}
		else {
			this.description = taskDescription;
		}
	}
	
	private void checkTaskId(String taskId) {
		if(taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException( "ID is invalid. ID cannot be empty or longer than 10 characters.");
		}
		else {
			this.taskId = taskId;
		}
	}
}
