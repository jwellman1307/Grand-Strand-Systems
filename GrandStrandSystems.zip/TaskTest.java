package Test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import Task.Task;


class TaskTest {
	
	private String id, name, description;
	private String IdTooLong, NameTooLong, DescriptionTooLong;

	@BeforeEach
	void setUp() {
		id = "1234567890";
		name = "July Wellman";
		description = "Test this description.";
		IdTooLong = "12345678910";
		NameTooLong = "A really really long name.";
		DescriptionTooLong = "We are testing for descriptions that are too long. This is a really long description.";
	}
	
	@Test
	void getTaskIdTest() {
		Task task = new Task(id);
		Assertions.assertEquals(id, task.getTaskId());
	}
	
	@ Test
	void getNameTest() {
		Task task = new Task(id, name);
		Assertions.assertEquals(name, task.getName());
	}
	
	@Test
	void getDescriptionTest() {
		Task task = new Task(id, name, description);
		Assertions.assertEquals(description, task.getDescription());
	}
	
	@Test
	void setNameTest() {
		Task task = new Task();
		task.setName(name);
		Assertions.assertEquals(name, task.getName());
	}
	
	@Test
	void setDescriptionTest() {
		Task task = new Task();
		task.setDescription(description);
		Assertions.assertEquals(description, task.getDescription());
	}
	
	@Test 
	void TaskIdTooLongTest() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> new Task(IdTooLong));
	}
	
	@Test
	void setTooLongNameTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setName(NameTooLong));
	}
	
	@Test
	void setTooLongDescriptionTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,  () -> task.setDescription(DescriptionTooLong));
	}
	
	@Test
	void TaskIdNullTest() {
		Assertions.assertThrows(IllegalArgumentException.class,  () -> new Task(null));
	}
	
	@Test
	void TaskNameNullTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,  () -> task.setName(null));
	}
	
	@Test void TaskDecriptionNullTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,  () -> task.setDescription(null));
	}

}
